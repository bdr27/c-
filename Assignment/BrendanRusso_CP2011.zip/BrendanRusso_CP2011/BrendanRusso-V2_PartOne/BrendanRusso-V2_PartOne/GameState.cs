﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BrendanRusso_V2_PartOne
{
    public enum GameState
    {
        WAIT_PLAYER1, WAIT_PLAYER2, PLAYER1_MOVING, PLAYER2_MOVING
    }
}
