﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BrendanRusso_V2_PartOne
{
    public enum Piece
    {
        PLAYER1, PLAYER2, EMPTY
    }
}
